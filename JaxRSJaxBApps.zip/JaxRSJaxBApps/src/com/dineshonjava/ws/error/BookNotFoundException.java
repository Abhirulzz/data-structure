package com.dineshonjava.ws.error;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

/**
 * @author Dinesh Rajput
 *
 */
public class BookNotFoundException extends WebApplicationException {  
	/**
	 * version
	 */
	private static final long serialVersionUID = 1L;

	public BookNotFoundException(String message) {  
		super(Response.status(Status.NOT_FOUND).entity(message).type(  
				MediaType.TEXT_PLAIN).build());  
	    } 
}
