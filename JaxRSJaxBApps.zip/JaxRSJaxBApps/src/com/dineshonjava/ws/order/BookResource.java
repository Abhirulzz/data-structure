package com.dineshonjava.ws.order;

import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import com.dineshonjava.ws.error.BookNotFoundException;
import com.dineshonjava.ws.rest.GetBooksResponse;
import com.dineshonjava.ws.xml.Book;
import com.dineshonjava.ws.xml.PublishedBooks;
import com.dineshonjava.ws.xml.Student;

/**
 * @author Dinesh Rajput
 *
 */
@Path("/order/books")
public class BookResource {
	@GET  
	@Produces("text/xml")  
	public GetBooksResponse getBooks() {  
       
		GetBooksResponse response = new GetBooksResponse();  
		Student student = new Student();  
		PublishedBooks publishedBooks1;  
		PublishedBooks publishedBooks2;  
   
		// student  
		student.setRollNumber(12345);  
		student.setName("Dinesh Rajput");  
		student.setCourse("Computer Science");  
		response.setStudent(student);  
       
		// first book  
		Book book1 = new Book();  
		book1.setPublishNumber(54321);  
		book1.setPublishDate(new Date()); 
		book1.setBookName("Java");
   
		publishedBooks1 = new PublishedBooks();  
		publishedBooks1.setBookId(77777);  
		publishedBooks1.setDescription("winning lottery ticket");  
		publishedBooks1.setQuantity((short) 10);  
		publishedBooks1.setUnitPrice(5.00F);  
   
		publishedBooks2 = new PublishedBooks();  
		publishedBooks2.setBookId(12121212);  
		publishedBooks2.setDescription("Real World Java EE Patterns Rethinking Best Practices");  
		publishedBooks2.setQuantity((short) 1);  
		publishedBooks2.setUnitPrice(40.40F);  
   
		book1.setPublishedBooks(new PublishedBooks[] { publishedBooks1, publishedBooks2 } );  
		response.getBooks().add(book1);  
   
		// second book  
		Book book2 = new Book();  
		book2.setPublishNumber(12345);  
		book2.setPublishDate(new Date());  
   
		publishedBooks1 = new PublishedBooks();  
		publishedBooks1.setBookId(787878);  
		publishedBooks1.setDescription("JavaServer Faces 2.0, The Complete Reference");  
		publishedBooks1.setQuantity((short) 10);  
		publishedBooks1.setUnitPrice(31.49F);  
   
		publishedBooks2 = new PublishedBooks();  
		publishedBooks2.setBookId(1111111);  
		publishedBooks2.setDescription("Beginning Java EE 6 with GlassFish 3, Second Edition");  
		publishedBooks2.setQuantity((short) 1);  
		publishedBooks2.setUnitPrice(41.73F);  
   
		book2.setPublishedBooks(new PublishedBooks[] { publishedBooks1, publishedBooks1 } );  
		response.getBooks().add(book2);  
       
		return response;  
   }
	
	@GET  
	@Path("{publishNumber}")  
	@Produces(MediaType.TEXT_PLAIN)  
	public Response updateOrder(@PathParam("publishNumber") String publishNumber) throws BookNotFoundException {  
	   
		ResponseBuilder response;  
	    
	    if ("12345".equals(publishNumber)) {  
	      response = Response.status(Response.Status.ACCEPTED).entity( "Saved changes to book '" +publishNumber+ "'.");  
	    } else {  
	      throw new BookNotFoundException("Publisher number '" + publishNumber +  
	          "' does not exist.");  
	    }  
	    return response.build();  
	  }

}
