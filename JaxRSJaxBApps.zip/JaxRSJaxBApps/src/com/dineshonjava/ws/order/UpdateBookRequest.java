package com.dineshonjava.ws.order;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.dineshonjava.ws.xml.Book;

/**
 * @author Dinesh Rajput
 *
 */
@XmlRootElement
public class UpdateBookRequest {
	private Book  book;
	
	@XmlElement
	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}
	
}
