package com.pluralsight.bridge.shape2;

public interface Color {

	public void applyColor();
	
}
